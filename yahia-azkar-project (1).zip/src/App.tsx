import React, { useCallback, useEffect, useState } from 'react';
import { Capacitor } from '@capacitor/core';
import {
  Bell,
  BookOpen,
  Compass,
  Home,
  Settings,
  Sparkles,
  WifiOff,
} from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';
import { AppFooter } from './components/AppFooter';
import { HomeView } from './components/HomeView';
import { PWAInstallButton } from './components/PWAInstallButton';
import { QuranAzkarView } from './components/QuranAzkarView';
import { RemindersView } from './components/RemindersView';
import { SettingsView } from './components/SettingsView';
import { TasbeehView } from './components/TasbeehView';
import {
  playReminderAudio,
  startBackgroundKeepAlive,
  syncReminderWithServiceWorker,
  triggerHaptic,
} from './utils/reminderAudio';
import {
  type AppSettings,
  DEFAULT_REMINDER_CONFIG,
  DEFAULT_SETTINGS,
  DEFAULT_TASBEEH_STATE,
  loadLocalSync,
  loadReminderConfigPersisted,
  loadSettingsPersisted,
  loadTasbeehPersisted,
  normalizeTasbeehState,
  type ReminderConfig,
  saveReminderConfigPersisted,
  saveSettingsPersisted,
  saveTasbeehPersisted,
  type TasbeehState,
} from './utils/storage';

type TabKey = 'home' | 'tasbeeh' | 'reminders' | 'quran' | 'settings';

const NAV_ITEMS: Array<{ key: TabKey; label: string; icon: React.ComponentType<{ className?: string }> }> = [
  { key: 'home', label: 'الرئيسية', icon: Home },
  { key: 'tasbeeh', label: 'العداد', icon: Sparkles },
  { key: 'reminders', label: 'التذكير', icon: Bell },
  { key: 'quran', label: 'القرآن', icon: BookOpen },
  { key: 'settings', label: 'الإعدادات', icon: Settings },
];

function isQuietNow(cfg: ReminderConfig): boolean {
  if (!cfg.quietHoursEnabled) return false;
  const h = new Date().getHours();
  if (cfg.quietStartHour <= cfg.quietEndHour) {
    return h >= cfg.quietStartHour && h < cfg.quietEndHour;
  }
  return h >= cfg.quietStartHour || h < cfg.quietEndHour;
}

export default function App() {
  const [activeTab, setActiveTab] = useState<TabKey>('home');
  const [tasbeeh, setTasbeeh] = useState<TasbeehState>(() =>
    normalizeTasbeehState(loadLocalSync('yd_tasbeeh', DEFAULT_TASBEEH_STATE))
  );
  const [reminder, setReminder] = useState<ReminderConfig>(() =>
    loadLocalSync('yd_reminder', DEFAULT_REMINDER_CONFIG)
  );
  const [settings, setSettings] = useState<AppSettings>(() =>
    loadLocalSync('yd_settings', DEFAULT_SETTINGS)
  );
  const [isOnline, setIsOnline] = useState<boolean>(
    typeof navigator !== 'undefined' ? navigator.onLine : true
  );
  const [activeToast, setActiveToast] = useState<string | null>(null);

  // Hydrate from IndexedDB on mount
  useEffect(() => {
    void (async () => {
      const [t, r, s] = await Promise.all([
        loadTasbeehPersisted(),
        loadReminderConfigPersisted(),
        loadSettingsPersisted(),
      ]);
      setTasbeeh(t);
      setReminder(r);
      setSettings(s);

      if (r.enabled) {
        void syncReminderWithServiceWorker(r);
        if (r.backgroundKeepAlive) {
          startBackgroundKeepAlive(r.customDhikr.trim() || r.selectedDhikr);
        }
      }
    })();
  }, []);

  // Online/offline detection
  useEffect(() => {
    const onOnline = () => setIsOnline(true);
    const onOffline = () => setIsOnline(false);
    window.addEventListener('online', onOnline);
    window.addEventListener('offline', onOffline);
    return () => {
      window.removeEventListener('online', onOnline);
      window.removeEventListener('offline', onOffline);
    };
  }, []);

  // Listen to Service Worker messages & notification click query param
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.get('playReminder') === '1') {
      void playReminderAudio(reminder.soundVolume);
      window.history.replaceState({}, '', '/');
    }

    if (!('serviceWorker' in navigator)) return;
    const handleSWMessage = (event: MessageEvent) => {
      const data = event.data as { type?: string; phrase?: string } | undefined;
      if (data?.type === 'PLAY_REMINDER_AUDIO') {
        if (reminder.soundEnabled) {
          void playReminderAudio(reminder.soundVolume);
        }
        setActiveToast(data.phrase || reminder.customDhikr.trim() || reminder.selectedDhikr);
        setTimeout(() => setActiveToast(null), 6000);
      }
    };

    navigator.serviceWorker.addEventListener('message', handleSWMessage);
    return () => navigator.serviceWorker.removeEventListener('message', handleSWMessage);
  }, [reminder.soundEnabled, reminder.soundVolume, reminder.customDhikr, reminder.selectedDhikr]);

  const updateTasbeeh = useCallback((next: TasbeehState) => {
    setTasbeeh(next);
    void saveTasbeehPersisted(next);
  }, []);

  const updateReminder = useCallback((next: ReminderConfig) => {
    setReminder(next);
    void saveReminderConfigPersisted(next);
    void syncReminderWithServiceWorker(next);
  }, []);

  const updateSettings = useCallback((patch: Partial<AppSettings>) => {
    setSettings((prev) => {
      const next = { ...prev, ...patch };
      void saveSettingsPersisted(next);
      return next;
    });
  }, []);

  // Foreground/background-tab interval scheduler
  useEffect(() => {
    if (!reminder.enabled || !reminder.nextTriggerAt) return;

    const timer = setInterval(() => {
      const now = Date.now();
      if (reminder.nextTriggerAt && now >= reminder.nextTriggerAt) {
        const intervalMs = Math.max(1, reminder.intervalMinutes) * 60 * 1000;
        const missedSteps = Math.floor((now - reminder.nextTriggerAt) / intervalMs) + 1;
        const nextTriggerAt = reminder.nextTriggerAt + missedSteps * intervalMs;
        const isNative = Capacitor.isNativePlatform();

        if (!isQuietNow(reminder)) {
          const phrase = reminder.customDhikr.trim() || reminder.selectedDhikr;
          setActiveToast(phrase);
          setTimeout(() => setActiveToast(null), 6000);

          // On native Android, AzkarAlarmReceiver fires the notification & sound on the Notification stream automatically.
          if (!isNative) {
            if (reminder.soundEnabled) {
              void playReminderAudio(reminder.soundVolume);
            }
            if (reminder.vibrateEnabled) {
              triggerHaptic([160, 80, 160]);
            }
            if (
              settings.notificationsEnabled &&
              'serviceWorker' in navigator &&
              typeof Notification !== 'undefined' &&
              Notification.permission === 'granted'
            ) {
              void navigator.serviceWorker.ready.then((reg) =>
                reg.showNotification('✨ {𝐘𝐀𝐇𝐈𝐀} صلّى على الحبيب ♥', {
                  body: `${phrase}\nسبحان الله والحمد لله والله أكبر`,
                  icon: '/pwa-192x192.png',
                  badge: '/pwa-192x192.png',
                  tag: 'azkar-scheduled-reminder',
                  data: { url: '/?playReminder=1', phrase },
                })
              );
            }
          }
        }

        const updated: ReminderConfig = {
          ...reminder,
          nextTriggerAt,
        };
        setReminder(updated);
        void saveReminderConfigPersisted(updated);
        if (!isNative) {
          void syncReminderWithServiceWorker(updated);
        }
      }
    }, 1000);

    return () => clearInterval(timer);
  }, [reminder, settings.notificationsEnabled]);

  const handleTabChange = (tab: TabKey) => {
    setActiveTab(tab);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-dvh w-full max-w-full overflow-x-clip bg-islamic-mesh flex flex-col">
      {/* Compact Sticky Top Header */}
      <header className="sticky top-0 z-30 h-12 sm:h-14 border-b border-violet-300/15 bg-[#130a35]/85 backdrop-blur-md">
        <div className="mx-auto flex h-full max-w-6xl items-center justify-between gap-4 px-4">
          <button
            type="button"
            onClick={() => handleTabChange('home')}
            className="flex items-center gap-2 text-right whitespace-nowrap shrink-0"
          >
            <Compass className="h-5 w-5 text-amber-300 shrink-0" />
            <span className="text-sm sm:text-base font-extrabold tracking-wide text-white">
              𝐘𝐀𝐇𝐈𝐀 𝐃𝐈𝐒𝐓𝐑𝐎𝐕𝐀
            </span>
          </button>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-1.5">
            {NAV_ITEMS.map((item) => {
              const Icon = item.icon;
              const active = activeTab === item.key;
              return (
                <button
                  key={item.key}
                  type="button"
                  onClick={() => handleTabChange(item.key)}
                  className={`btn-glow flex items-center gap-1.5 rounded-xl px-3.5 py-2 text-xs font-bold whitespace-nowrap shrink-0 transition-colors ${
                    active
                      ? 'bg-gradient-to-l from-violet-600 to-blue-600 text-white shadow-md'
                      : 'text-slate-300 hover:bg-white/10 hover:text-white'
                  }`}
                >
                  <Icon className="h-4 w-4 shrink-0" />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </nav>

          <div className="flex items-center gap-2 shrink-0">
            <PWAInstallButton compact />
          </div>
        </div>
      </header>

      {/* Main Scrollable Viewport */}
      <main className="mx-auto w-full min-w-0 max-w-6xl flex-1 px-4 pt-5 pb-24 md:pb-10">
        {!isOnline && (
          <div className="mb-4 flex items-center gap-2 rounded-2xl border border-amber-400/35 bg-amber-950/50 px-4 py-2.5 text-xs font-semibold text-amber-200">
            <WifiOff className="h-4 w-4 shrink-0" />
            <span>وضع عدم الاتصال — العداد ومواقيت الصلاة والأذكار والسور المحفوظة تعمل بكفاءة</span>
          </div>
        )}

        <AnimatePresence>
          {activeToast && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="mb-5 flex items-center justify-between gap-3 rounded-2xl border border-amber-300/45 bg-gradient-to-l from-violet-900/90 to-blue-900/90 p-4 shadow-xl"
            >
              <div className="flex items-center gap-3">
                <Bell className="h-5 w-5 text-amber-300 shrink-0" />
                <div>
                  <p className="text-xs font-bold text-amber-300">تذكير بالذكر الآن</p>
                  <p className="text-sm font-bold text-white">{activeToast}</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setActiveToast(null)}
                className="rounded-xl bg-white/10 px-3 py-1.5 text-xs font-bold text-white"
              >
                إغلاق
              </button>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Smooth Page Transitions */}
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
          >
            {activeTab === 'home' && (
              <HomeView
                tasbeeh={tasbeeh}
                reminder={reminder}
                settings={settings}
                onUpdateSettings={updateSettings}
                onNavigate={handleTabChange}
              />
            )}
            {activeTab === 'tasbeeh' && (
              <TasbeehView
                tasbeeh={tasbeeh}
                settings={settings}
                onUpdateTasbeeh={updateTasbeeh}
              />
            )}
            {activeTab === 'reminders' && (
              <RemindersView
                reminder={reminder}
                onUpdateReminder={updateReminder}
              />
            )}
            {activeTab === 'quran' && (
              <QuranAzkarView
                settings={settings}
                onUpdateSettings={updateSettings}
              />
            )}
            {activeTab === 'settings' && (
              <SettingsView
                settings={settings}
                reminder={reminder}
                onUpdateSettings={updateSettings}
                onUpdateReminder={updateReminder}
                onNavigateReminders={() => handleTabChange('reminders')}
              />
            )}
          </motion.div>
        </AnimatePresence>

        <AppFooter />
      </main>

      {/* Mobile Bottom Navigation Bar */}
      <nav
        aria-label="التنقل الرئيسي"
        className="fixed bottom-0 left-0 right-0 z-40 h-[60px] border-t border-violet-300/20 bg-[#120933]/92 backdrop-blur-md md:hidden"
      >
        <div className="grid h-full grid-cols-5 items-center">
          {NAV_ITEMS.map((item) => {
            const Icon = item.icon;
            const active = activeTab === item.key;
            return (
              <button
                key={item.key}
                type="button"
                onClick={() => handleTabChange(item.key)}
                className={`btn-glow flex h-full min-h-[44px] flex-col items-center justify-center gap-0.5 transition-colors ${
                  active ? 'text-amber-300' : 'text-slate-300 hover:text-white'
                }`}
              >
                <Icon className={`h-5 w-5 ${active ? 'scale-110' : ''}`} />
                <span className="text-[11px] font-bold tracking-tight whitespace-nowrap">
                  {item.label}
                </span>
              </button>
            );
          })}
        </div>
      </nav>
    </div>
  );
}
