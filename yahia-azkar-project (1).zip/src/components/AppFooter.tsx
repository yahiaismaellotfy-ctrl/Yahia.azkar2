import React, { useState } from 'react';
import { Code2, ExternalLink, Heart, MessageCircle, Sparkles } from 'lucide-react';

export const WHATSAPP_CHANNEL_URL = 'https://whatsapp.com/channel/0029VbBHjuc35fLzD0p4Fu0u';
export const APP_COVER_IMAGE = '/assets/aistudio/file_000000005e0482469815059f1f5a3acd_69bd9b10.png';
export const DEVELOPER_AVATAR_IMAGE = '/assets/aistudio/YAHIA_DISTROVA_2MB_9b532cd6.jpg';

export const AppFooter: React.FC = () => {
  const [imgError, setImgError] = useState(false);

  return (
    <footer className="relative mt-8 overflow-hidden rounded-3xl border border-amber-300/25 bg-gradient-to-br from-[#1f104e]/95 via-[#151247]/95 to-[#0b1f54]/95 p-5 sm:p-6 shadow-2xl">
      {/* Subtle Top Golden Hairline */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-x-0 top-0 h-[2px] bg-gradient-to-l from-transparent via-amber-400/75 to-transparent"
      />

      <div className="relative flex flex-col gap-5 sm:flex-row sm:items-center sm:justify-between">
        {/* Developer Identity Card */}
        <div className="flex items-center gap-4 min-w-0">
          <div className="relative shrink-0">
            <div
              aria-hidden="true"
              className="absolute -inset-1 rounded-2xl bg-gradient-to-br from-amber-400/45 via-violet-500/45 to-blue-500/45 blur-sm"
            />
            {!imgError ? (
              <img
                src={DEVELOPER_AVATAR_IMAGE}
                alt="شعار المطور YAHIA DISTROVA"
                referrerPolicy="no-referrer"
                onError={() => setImgError(true)}
                className="relative h-16 w-16 sm:h-[72px] sm:w-[72px] rounded-2xl border-2 border-amber-300/60 object-cover shadow-xl"
              />
            ) : (
              <div className="relative flex h-16 w-16 sm:h-[72px] sm:w-[72px] items-center justify-center rounded-2xl border-2 border-amber-300/60 bg-gradient-to-br from-violet-700 to-blue-700 text-amber-200">
                <Heart className="h-7 w-7" />
              </div>
            )}
          </div>

          <div className="min-w-0 flex-1">
            <div className="flex flex-wrap items-center gap-2">
              <span className="inline-flex items-center gap-1 rounded-lg border border-amber-300/35 bg-amber-400/15 px-2 py-0.5 text-[11px] font-bold text-amber-200">
                <Code2 className="h-3 w-3 shrink-0" />
                <span>تصميم وتطوير</span>
              </span>
              <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-violet-200">
                <Sparkles className="h-3 w-3 text-amber-300 shrink-0" />
                <span>نسخة الأندرويد والويب</span>
              </span>
            </div>

            <h3 className="mt-1.5 text-lg sm:text-xl font-extrabold tracking-wide text-white truncate">
              𝐘𝐀𝐇𝐈𝐀 𝐃𝐈𝐒𝐓𝐑𝐎𝐕𝐀
            </h3>

            <p className="mt-0.5 text-xs leading-relaxed text-slate-300">
              {'{𝐘𝐀𝐇𝐈𝐀}'}صلـى عـلى الـحـبيـب♥✨ · صدقة جارية وذكر لا ينقطع
            </p>
          </div>
        </div>

        {/* Distinctive WhatsApp Channel Card CTA */}
        <a
          href={WHATSAPP_CHANNEL_URL}
          target="_blank"
          rel="noopener noreferrer"
          className="btn-glow group flex items-center justify-between gap-3 rounded-2xl border border-emerald-300/40 bg-gradient-to-l from-emerald-600 via-emerald-600 to-teal-600 px-4 py-3 text-white shadow-xl shadow-emerald-950/50 sm:min-w-[235px] shrink-0"
        >
          <div className="flex items-center gap-3 min-w-0">
            <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-white/15 text-white ring-1 ring-white/25">
              <MessageCircle className="h-5 w-5" />
            </span>
            <div className="text-right min-w-0">
              <p className="text-[11px] font-semibold text-emerald-100">
                القناة الرسمية للمطور
              </p>
              <p className="text-sm font-extrabold text-white whitespace-nowrap">
                انضم لقناة الواتساب
              </p>
            </div>
          </div>
          <ExternalLink className="h-4 w-4 text-emerald-100 opacity-90 transition-transform group-hover:-translate-x-0.5 shrink-0" />
        </a>
      </div>
    </footer>
  );
};
