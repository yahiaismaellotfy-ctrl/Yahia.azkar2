import React, { useEffect, useMemo, useState } from 'react';
import {
  Bell,
  Calendar,
  Clock,
  Compass,
  MapPin,
  Pause,
  Play,
  Sparkles,
  Volume2,
} from 'lucide-react';
import { CITIES, computePrayerSchedule } from '../utils/prayerTimes';
import { playReminderAudio, stopReminderAudio } from '../utils/reminderAudio';
import type { AppSettings, ReminderConfig, TasbeehState } from '../utils/storage';

const SHEIKH_PORTRAIT = '/src/assets/images/sheikh_muhammad_rifaat_1794866003423.jpg';

interface HomeViewProps {
  tasbeeh: TasbeehState;
  reminder: ReminderConfig;
  settings: AppSettings;
  onUpdateSettings: (patch: Partial<AppSettings>) => void;
  onNavigate: (tab: 'home' | 'tasbeeh' | 'reminders' | 'quran' | 'settings') => void;
}

export const HomeView: React.FC<HomeViewProps> = ({
  tasbeeh,
  reminder,
  settings,
  onUpdateSettings,
  onNavigate,
}) => {
  const [now, setNow] = useState<Date>(() => new Date());
  const [imgError, setImgError] = useState(false);
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const [locating, setLocating] = useState(false);
  const [locationError, setLocationError] = useState<string | null>(null);

  useEffect(() => {
    const id = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(id);
  }, []);

  const dayNameAr = useMemo(
    () =>
      now.toLocaleDateString('ar-EG', {
        weekday: 'long',
      }),
    [now]
  );

  const gregorianDateAr = useMemo(
    () =>
      now.toLocaleDateString('ar-EG', {
        day: 'numeric',
        month: 'long',
        year: 'numeric',
      }),
    [now]
  );

  const hijriDateAr = useMemo(() => {
    try {
      return new Intl.DateTimeFormat('ar-SA-u-ca-islamic-umalqura', {
        day: 'numeric',
        month: 'long',
        year: 'numeric',
      }).format(now);
    } catch {
      return '';
    }
  }, [now]);

  const timeParts = useMemo(() => {
    const hours24 = now.getHours();
    const period = hours24 >= 12 ? 'م' : 'ص';
    const h12 = hours24 % 12 || 12;
    const pad = (n: number) => String(n).padStart(2, '0');
    return {
      hhmm: `${pad(h12)}:${pad(now.getMinutes())}`,
      sec: pad(now.getSeconds()),
      period,
    };
  }, [now]);

  const prayerSchedule = useMemo(
    () => computePrayerSchedule(settings.cityId, settings.customCoords, now),
    [settings.cityId, settings.customCoords, now]
  );

  const handleToggleAudio = async () => {
    if (isPlayingAudio) {
      stopReminderAudio();
      setIsPlayingAudio(false);
      return;
    }
    setIsPlayingAudio(true);
    const ok = await playReminderAudio(reminder.soundVolume, () => {
      setIsPlayingAudio(false);
    });
    if (!ok) {
      setIsPlayingAudio(false);
    }
  };

  const handleUseGPS = () => {
    if (!('geolocation' in navigator)) {
      setLocationError('المتصفح لا يدعم تحديد الموقع التلقائي');
      return;
    }
    setLocating(true);
    setLocationError(null);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        onUpdateSettings({
          customCoords: {
            lat: pos.coords.latitude,
            lng: pos.coords.longitude,
            label: 'موقعك الحالي (GPS)',
          },
        });
        setLocating(false);
      },
      () => {
        setLocationError('تعذر الوصول للموقع — يمكنك اختيار المدينة من القائمة');
        setLocating(false);
      },
      { timeout: 8000 }
    );
  };

  const progressPct = Math.min(100, Math.round((tasbeeh.currentCount / Math.max(1, tasbeeh.dailyGoal)) * 100));

  return (
    <div className="w-full min-w-0 space-y-6">
      {/* Top Hero Row: Portrait of Sheikh Muhammad Rifaat + Live Clock & Dates */}
      <section className="grid grid-cols-1 gap-5 lg:grid-cols-12 items-stretch">
        {/* Sheikh Muhammad Rifaat Spotlight */}
        <div className="min-w-0 lg:col-span-7 relative overflow-hidden rounded-3xl border border-violet-300/20 bg-gradient-to-br from-violet-950/75 via-[#1a114d]/85 to-blue-950/80 p-5 sm:p-6 shadow-2xl flex flex-col justify-between">
          <div className="flex flex-col sm:flex-row items-center sm:items-start gap-5">
            <div className="relative shrink-0">
              {!imgError ? (
                <img
                  src={SHEIKH_PORTRAIT}
                  alt="فضيلة الشيخ محمد رفعت رحمه الله"
                  referrerPolicy="no-referrer"
                  onError={() => setImgError(true)}
                  className="h-32 w-32 sm:h-36 sm:w-36 rounded-2xl border-2 border-amber-300/45 object-cover shadow-xl shadow-black/40"
                />
              ) : (
                <div className="flex h-32 w-32 sm:h-36 sm:w-36 items-center justify-center rounded-2xl border-2 border-amber-300/45 bg-gradient-to-br from-violet-800 to-blue-900 text-center text-xs font-bold text-amber-200 p-3">
                  الشيخ محمد رفعت رحمه الله
                </div>
              )}
            </div>

            <div className="flex-1 text-center sm:text-right min-w-0">
              <p className="text-xs font-semibold text-amber-300/95">
                قيثارة السماء · فضيلة الشيخ محمد رفعت رحمه الله
              </p>
              <h1 className="mt-1.5 text-2xl sm:text-3xl font-extrabold tracking-tight text-white [text-wrap:balance]">
                𝐘𝐀𝐇𝐈𝐀 𝐃𝐈𝐒𝐓𝐑𝐎𝐕𝐀
              </h1>
              <p className="mt-2 font-quran text-xl sm:text-2xl text-amber-200 leading-relaxed">
                ﴿ أَلَا بِذِكْرِ اللَّهِ تَطْمَئِنُّ الْقُلُوبُ ﴾
              </p>
              <p className="mt-1.5 text-xs sm:text-sm text-slate-300">
                صلّ على الحبيب محمد ﷺ واجعل لسانك رطباً بذكر الله في كل وقت
              </p>
            </div>
          </div>

          <div className="mt-5 flex flex-wrap items-center justify-center sm:justify-start gap-3">
            <button
              type="button"
              onClick={() => onNavigate('tasbeeh')}
              className="btn-glow min-h-[44px] flex items-center gap-2 rounded-2xl bg-gradient-to-l from-violet-600 to-blue-600 px-5 py-2.5 text-sm font-bold text-white shadow-lg shadow-violet-900/40"
            >
              <Sparkles className="h-4 w-4 shrink-0" />
              <span>ابدأ التسبيح الآن</span>
            </button>

            <button
              type="button"
              onClick={() => void handleToggleAudio()}
              className="btn-glow min-h-[44px] flex items-center gap-2 rounded-2xl border border-violet-300/25 bg-white/10 px-4 py-2.5 text-sm font-semibold text-violet-100 hover:bg-white/15"
            >
              {isPlayingAudio ? (
                <>
                  <Pause className="h-4 w-4 text-amber-300 shrink-0" />
                  <span>إيقاف صوت التذكير</span>
                </>
              ) : (
                <>
                  <Volume2 className="h-4 w-4 text-amber-300 shrink-0" />
                  <span>سماع صوت التذكير</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Live Digital Clock & Hijri/Gregorian Date */}
        <div className="min-w-0 lg:col-span-5 rounded-3xl border border-blue-300/20 bg-gradient-to-br from-[#17124a]/90 to-[#0c1c4e]/90 p-5 sm:p-6 shadow-2xl flex flex-col justify-between">
          <div className="flex items-center justify-between text-xs font-semibold text-blue-200/90">
            <span className="flex items-center gap-1.5">
              <Clock className="h-4 w-4 text-violet-300" />
              <span>الساعة والتاريخ اليوم</span>
            </span>
            <span>{dayNameAr}</span>
          </div>

          <div className="my-4 flex items-baseline justify-center gap-2" dir="ltr">
            <span className="font-mono-num text-5xl sm:text-6xl font-bold tracking-tight text-white">
              {timeParts.hhmm}
            </span>
            <div className="flex flex-col items-start">
              <span className="font-mono-num text-lg font-bold text-violet-300">{timeParts.sec}</span>
              <span className="text-sm font-bold text-amber-300">{timeParts.period}</span>
            </div>
          </div>

          <div className="space-y-2 border-t border-white/10 pt-3 text-sm">
            {hijriDateAr && (
              <div className="flex items-center justify-between text-amber-200">
                <span className="flex items-center gap-1.5 text-xs text-slate-300">
                  <Calendar className="h-3.5 w-3.5 text-amber-300" />
                  التاريخ الهجري
                </span>
                <span className="font-semibold">{hijriDateAr}</span>
              </div>
            )}
            <div className="flex items-center justify-between text-slate-200">
              <span className="text-xs text-slate-300">التاريخ الميلادي</span>
              <span className="font-semibold">{gregorianDateAr}</span>
            </div>
          </div>
        </div>
      </section>

      {/* Prayer Times Section */}
      <section className="rounded-3xl border border-violet-300/20 bg-[#140e42]/75 p-5 sm:p-6 shadow-xl">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              <Compass className="h-5 w-5 text-amber-300" />
              <span>مواقيت الصلاة</span>
            </h2>
            <p className="mt-0.5 text-xs text-slate-300 flex items-center gap-1.5">
              <MapPin className="h-3.5 w-3.5 text-blue-300" />
              <span>{prayerSchedule.cityLabel}</span>
              <span aria-hidden="true">·</span>
              <span className="text-amber-300 font-semibold">
                الصلاة القادمة: {prayerSchedule.nextPrayer.nameAr} بعد{' '}
                <span className="font-mono-num" dir="ltr">
                  {prayerSchedule.remainingText}
                </span>
              </span>
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <select
              aria-label="اختر المدينة"
              value={settings.customCoords ? 'gps' : settings.cityId}
              onChange={(e) => {
                if (e.target.value === 'gps') return;
                onUpdateSettings({ cityId: e.target.value, customCoords: null });
              }}
              className="min-h-[44px] rounded-xl border border-violet-300/25 bg-[#1b1255] px-3 py-2 text-xs font-semibold text-white focus:outline-none focus:ring-2 focus:ring-violet-400"
            >
              {settings.customCoords && <option value="gps">{settings.customCoords.label}</option>}
              {CITIES.map((city) => (
                <option key={city.id} value={city.id}>
                  {city.nameAr} - {city.countryAr}
                </option>
              ))}
            </select>

            <button
              type="button"
              onClick={handleUseGPS}
              disabled={locating}
              className="btn-glow min-h-[44px] flex items-center gap-1.5 rounded-xl border border-blue-400/30 bg-blue-600/25 px-3.5 py-2 text-xs font-semibold text-blue-100 hover:bg-blue-600/35 disabled:opacity-50"
            >
              <MapPin className="h-4 w-4 shrink-0" />
              <span>{locating ? 'جاري التحديد...' : 'موقعي الحالي'}</span>
            </button>
          </div>
        </div>

        {locationError && (
          <p className="mt-2 text-xs text-amber-300">{locationError}</p>
        )}

        <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
          {prayerSchedule.prayers.map((prayer) => (
            <div
              key={prayer.key}
              className={`rounded-2xl border p-3.5 text-center transition-colors ${
                prayer.isNext
                  ? 'border-amber-400/60 bg-gradient-to-b from-violet-600/40 to-blue-700/40 shadow-lg shadow-violet-900/30'
                  : 'border-white/10 bg-white/5'
              }`}
            >
              <p className={`text-xs font-semibold ${prayer.isNext ? 'text-amber-300' : 'text-slate-300'}`}>
                {prayer.nameAr}
              </p>
              <p className="mt-1.5 font-mono-num text-base font-bold text-white">{prayer.formattedTime}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Quick Overview Cards: Daily Azkar Progress + Reminder Status */}
      <section className="grid grid-cols-1 gap-4 md:grid-cols-2">
        <button
          type="button"
          onClick={() => onNavigate('tasbeeh')}
          className="btn-glow group rounded-3xl border border-violet-300/20 bg-gradient-to-br from-violet-900/45 to-indigo-950/60 p-5 text-right shadow-xl"
        >
          <div className="flex items-center justify-between gap-3">
            <div className="min-w-0">
              <p className="text-xs font-semibold text-violet-200">
                {tasbeeh.counters.find((c) => c.id === tasbeeh.activeCounterId)?.name || 'عداد الأذكار اليومي'}
                <span className="mx-1.5 opacity-60">·</span>
                <span className="text-amber-200">{tasbeeh.counters.length} عدادات</span>
              </p>
              <h3 className="mt-1 text-lg font-bold text-white line-clamp-1">{tasbeeh.selectedDhikr}</h3>
            </div>
            <span className="font-mono-num text-2xl font-extrabold text-amber-300 shrink-0">
              {tasbeeh.currentCount}/{tasbeeh.dailyGoal}
            </span>
          </div>
          <div className="mt-4 h-2.5 w-full overflow-hidden rounded-full bg-white/10">
            <div
              className="h-full rounded-full bg-gradient-to-l from-amber-400 via-violet-400 to-blue-400 transition-all duration-300"
              style={{ width: `${progressPct}%` }}
            />
          </div>
          <div className="mt-2.5 flex items-center justify-between text-xs text-slate-300">
            <span>إجمالي التسبيحات: {tasbeeh.totalLifetimeCount.toLocaleString('ar-EG')}</span>
            <span className="font-semibold text-violet-200 group-hover:text-white">إدارة العدادات ←</span>
          </div>
        </button>

        <button
          type="button"
          onClick={() => onNavigate('reminders')}
          className="btn-glow group rounded-3xl border border-blue-300/20 bg-gradient-to-br from-blue-900/40 to-violet-950/60 p-5 text-right shadow-xl"
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div
                className={`flex h-11 w-11 items-center justify-center rounded-2xl ${
                  reminder.enabled ? 'bg-emerald-500/25 text-emerald-300' : 'bg-white/10 text-slate-300'
                }`}
              >
                <Bell className="h-5 w-5" />
              </div>
              <div>
                <p className="text-xs font-semibold text-blue-200">نظام التذكير الصوتي التلقائي</p>
                <h3 className="mt-0.5 text-base font-bold text-white">
                  {reminder.enabled ? `مُفعّل — كل ${reminder.intervalMinutes} دقيقة` : 'متوقف حالياً'}
                </h3>
              </div>
            </div>
            <Play className="h-5 w-5 text-amber-300 shrink-0" />
          </div>
          <p className="mt-3 text-xs text-slate-300 line-clamp-1">
            الذكر المختار: {reminder.customDhikr.trim() || reminder.selectedDhikr}
          </p>
          <div className="mt-2 flex items-center justify-between text-xs text-slate-300">
            <span>يعمل في الخلفية وبصوت الذكر</span>
            <span className="font-semibold text-blue-200 group-hover:text-white">ضبط المواعيد ←</span>
          </div>
        </button>
      </section>
    </div>
  );
};
