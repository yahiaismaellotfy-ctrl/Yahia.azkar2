import React, { useCallback, useEffect, useState } from 'react';
import { Capacitor } from '@capacitor/core';
import {
  BatteryCharging,
  Bell,
  BellOff,
  CheckCircle2,
  Clock,
  Moon,
  Play,
  ShieldCheck,
  Volume2,
} from 'lucide-react';
import { DHIKR_PRESETS } from '../data/azkarData';
import {
  checkNotificationPermission,
  getNativeBackgroundStatus,
  type NativeBackgroundStatus,
  playReminderAudio,
  requestNativeBackgroundPermissions,
  requestNotificationPermission,
  sendTestReminderToSW,
  startBackgroundKeepAlive,
  stopBackgroundKeepAlive,
  triggerHaptic,
} from '../utils/reminderAudio';
import type { ReminderConfig } from '../utils/storage';

interface RemindersViewProps {
  reminder: ReminderConfig;
  onUpdateReminder: (next: ReminderConfig) => void;
}

const INTERVAL_OPTIONS = [
  { label: 'كل دقيقة', value: 1 },
  { label: 'كل ٥ دقائق', value: 5 },
  { label: 'كل ١٠ دقائق', value: 10 },
  { label: 'كل ١٥ دقيقة', value: 15 },
  { label: 'كل ٣٠ دقيقة', value: 30 },
  { label: 'كل ساعة', value: 60 },
  { label: 'كل ساعتين', value: 120 },
];

const HOURS_LIST = Array.from({ length: 24 }, (_, h) => {
  const period = h >= 12 ? 'م' : 'ص';
  const h12 = h % 12 || 12;
  return { value: h, label: `${h12}:00 ${period}` };
});

export const RemindersView: React.FC<RemindersViewProps> = ({
  reminder,
  onUpdateReminder,
}) => {
  const isNative = Capacitor.isNativePlatform();
  const [notifPermission, setNotifPermission] = useState<NotificationPermission>(
    !isNative && typeof Notification !== 'undefined' ? Notification.permission : 'default'
  );
  const [bgStatus, setBgStatus] = useState<NativeBackgroundStatus | null>(null);
  const [customMinutes, setCustomMinutes] = useState('');
  const [countdownText, setCountdownText] = useState('--:--');
  const [testFeedback, setTestFeedback] = useState<string | null>(null);

  const refreshDeviceStatus = useCallback(async () => {
    const [perm, nativeStatus] = await Promise.all([
      checkNotificationPermission(),
      getNativeBackgroundStatus(),
    ]);
    setNotifPermission(perm);
    if (nativeStatus) {
      setBgStatus(nativeStatus);
    }
  }, []);

  useEffect(() => {
    void refreshDeviceStatus();
    const onFocusOrVisible = () => {
      if (document.visibilityState === 'visible') {
        void refreshDeviceStatus();
      }
    };
    window.addEventListener('focus', onFocusOrVisible);
    document.addEventListener('visibilitychange', onFocusOrVisible);
    return () => {
      window.removeEventListener('focus', onFocusOrVisible);
      document.removeEventListener('visibilitychange', onFocusOrVisible);
    };
  }, [refreshDeviceStatus]);

  useEffect(() => {
    const updateCountdown = () => {
      if (!reminder.enabled || !reminder.nextTriggerAt) {
        setCountdownText('متوقف');
        return;
      }
      const diff = Math.max(0, reminder.nextTriggerAt - Date.now());
      const totalSec = Math.floor(diff / 1000);
      const hrs = Math.floor(totalSec / 3600);
      const mins = Math.floor((totalSec % 3600) / 60);
      const secs = totalSec % 60;
      const pad = (n: number) => String(n).padStart(2, '0');
      setCountdownText(
        hrs > 0
          ? `${pad(hrs)}:${pad(mins)}:${pad(secs)}`
          : `${pad(mins)}:${pad(secs)}`
      );
    };

    updateCountdown();
    const id = setInterval(updateCountdown, 1000);
    return () => clearInterval(id);
  }, [reminder.enabled, reminder.nextTriggerAt]);

  const handleToggleMaster = async () => {
    const nextEnabled = !reminder.enabled;
    if (nextEnabled) {
      const perm = await requestNotificationPermission();
      setNotifPermission(perm);
      await refreshDeviceStatus();
      if (reminder.backgroundKeepAlive) {
        startBackgroundKeepAlive(
          reminder.customDhikr.trim() || reminder.selectedDhikr
        );
      }
      const nextTriggerAt = Date.now() + reminder.intervalMinutes * 60 * 1000;
      onUpdateReminder({
        ...reminder,
        enabled: true,
        nextTriggerAt,
      });
    } else {
      stopBackgroundKeepAlive();
      onUpdateReminder({
        ...reminder,
        enabled: false,
        nextTriggerAt: null,
      });
    }
  };

  const handleSelectInterval = (minutes: number) => {
    const valid = Math.max(1, Math.min(1440, Math.round(minutes)));
    onUpdateReminder({
      ...reminder,
      intervalMinutes: valid,
      nextTriggerAt: reminder.enabled
        ? Date.now() + valid * 60 * 1000
        : reminder.nextTriggerAt,
    });
  };

  const handleRequestPermission = async () => {
    const perm = await requestNotificationPermission();
    setNotifPermission(perm);
    if (isNative && perm !== 'granted') {
      await requestNativeBackgroundPermissions();
    }
    await refreshDeviceStatus();
  };

  const handleEnableBackground = async () => {
    await requestNativeBackgroundPermissions();
    setTimeout(() => {
      void refreshDeviceStatus();
    }, 800);
  };

  const handleTestReminder = async () => {
    const perm = await requestNotificationPermission();
    setNotifPermission(perm);
    await refreshDeviceStatus();

    const phrase =
      reminder.customDhikr.trim() ||
      reminder.selectedDhikr ||
      'سبحان الله والحمد لله والله أكبر — اللهم صلّ وسلم على نبينا محمد ﷺ';

    if (isNative) {
      // On Android native, AzkarAlarmReceiver posts the notification on azkar_notif_channel_v2
      // which plays on Android's Notification stream automatically without overlapping audio.
      await sendTestReminderToSW(
        phrase,
        reminder.soundEnabled,
        reminder.vibrateEnabled
      );
      if (perm !== 'granted' && reminder.soundEnabled) {
        await playReminderAudio(reminder.soundVolume);
      }
    } else {
      if (reminder.soundEnabled) {
        await playReminderAudio(reminder.soundVolume);
      }
      if (reminder.vibrateEnabled) {
        triggerHaptic([150, 80, 150]);
      }
      await sendTestReminderToSW(
        phrase,
        reminder.soundEnabled,
        reminder.vibrateEnabled
      );
    }

    setTestFeedback('تم إرسال إشعار وتنبيه صوتي تجريبي بصوت الإشعارات');
    setTimeout(() => setTestFeedback(null), 4000);
  };

  const needsNativeBgBoost =
    isNative && bgStatus && (!bgStatus.canExactAlarms || !bgStatus.ignoringBattery);

  return (
    <div className="w-full min-w-0 space-y-6">
      {/* Master Toggle & Live Status Banner */}
      <section className="rounded-3xl border border-violet-300/20 bg-gradient-to-br from-[#1d1154]/90 via-[#17124d]/85 to-[#0b1f54]/90 p-5 sm:p-6 shadow-2xl">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-start gap-4 min-w-0">
            <div
              className={`flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl border ${
                reminder.enabled
                  ? 'border-emerald-400/50 bg-emerald-500/20 text-emerald-300'
                  : 'border-white/15 bg-white/10 text-slate-300'
              }`}
            >
              {reminder.enabled ? (
                <Bell className="h-7 w-7" />
              ) : (
                <BellOff className="h-7 w-7" />
              )}
            </div>
            <div className="min-w-0">
              <h2 className="text-xl font-extrabold text-white">
                نظام التذكير التلقائي
              </h2>
              <p className="mt-1 text-xs sm:text-sm text-slate-300">
                {reminder.enabled
                  ? `التنبيه القادم خلال ${countdownText} — كل ${reminder.intervalMinutes} دقيقة`
                  : 'قم بتشغيل التذكير ليصلك صوت الذكر والإشعارات حتى في الخلفية'}
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              type="button"
              onClick={() => void handleToggleMaster()}
              className={`btn-glow min-h-[48px] rounded-2xl px-6 py-2.5 text-sm font-bold text-white shadow-lg whitespace-nowrap shrink-0 ${
                reminder.enabled
                  ? 'bg-gradient-to-l from-rose-600 to-amber-600'
                  : 'bg-gradient-to-l from-emerald-600 to-teal-600'
              }`}
            >
              {reminder.enabled ? 'إيقاف التذكير' : 'تشغيل التذكير الآن'}
            </button>

            <button
              type="button"
              onClick={() => void handleTestReminder()}
              className="btn-glow min-h-[48px] flex items-center gap-2 rounded-2xl border border-amber-300/35 bg-amber-500/20 px-4 py-2.5 text-sm font-bold text-amber-200 whitespace-nowrap shrink-0"
            >
              <Play className="h-4 w-4 shrink-0" />
              <span>تجربة الصوت والإشعار</span>
            </button>
          </div>
        </div>

        {testFeedback && (
          <p className="mt-3 flex items-center gap-2 text-xs font-semibold text-emerald-300">
            <CheckCircle2 className="h-4 w-4 shrink-0" />
            <span>{testFeedback}</span>
          </p>
        )}

        {/* Notification Permission & Persistence Status */}
        <div className="mt-5 flex flex-col gap-3 rounded-2xl border border-white/10 bg-white/5 p-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-start gap-3 min-w-0">
            <ShieldCheck className="h-5 w-5 text-blue-300 shrink-0 mt-0.5" />
            <div className="text-xs leading-relaxed text-slate-200 min-w-0">
              <p className="font-bold text-white">
                حالة إذن الإشعارات في الجهاز:{' '}
                <span
                  className={
                    notifPermission === 'granted'
                      ? 'text-emerald-300'
                      : notifPermission === 'denied'
                      ? 'text-rose-300'
                      : 'text-amber-300'
                  }
                >
                  {notifPermission === 'granted'
                    ? 'مسموح (يعمل في الخلفية)'
                    : notifPermission === 'denied'
                    ? 'مرفوض — اضغط للسماح من الإعدادات'
                    : 'بانتظار التفعيل'}
                </span>
              </p>
              <p className="mt-1 text-slate-300">
                {isNative
                  ? 'يستخدم التطبيق منبّهات النظام الأصلية (AlarmManager) ليصل صوت الذكر عبر قناة الإشعارات حتى بعد إغلاق التطبيق من الخلفية أو إعادة تشغيل الهاتف.'
                  : 'تُحفظ المواعيد داخل قاعدة بيانات الجهاز (IndexedDB + Service Worker) لتستمر المزامنة حتى بعد إغلاق التطبيق أو إعادة تشغيل الهاتف.'}
              </p>
            </div>
          </div>

          {notifPermission !== 'granted' && (
            <button
              type="button"
              onClick={() => void handleRequestPermission()}
              className="btn-glow min-h-[44px] rounded-xl bg-violet-600 px-4 py-2 text-xs font-bold text-white whitespace-nowrap shrink-0"
            >
              السماح بالإشعارات
            </button>
          )}
        </div>

        {/* Native Android Background / Battery Optimization Helper */}
        {isNative && bgStatus && (
          <div
            className={`mt-3 flex flex-col gap-3 rounded-2xl border p-4 sm:flex-row sm:items-center sm:justify-between ${
              needsNativeBgBoost
                ? 'border-amber-400/40 bg-amber-950/35'
                : 'border-emerald-400/30 bg-emerald-950/25'
            }`}
          >
            <div className="flex items-start gap-3 min-w-0">
              <BatteryCharging
                className={`h-5 w-5 shrink-0 mt-0.5 ${
                  needsNativeBgBoost ? 'text-amber-300' : 'text-emerald-300'
                }`}
              />
              <div className="text-xs leading-relaxed text-slate-200 min-w-0">
                <p className="font-bold text-white">
                  {needsNativeBgBoost
                    ? 'لتشغيل الصوت والإشعارات بعد "إغلاق الكل":'
                    : 'منبّهات الخلفية والبطارية: مُفعّلة بالكامل'}
                </p>
                <p className="mt-0.5 text-slate-300">
                  {needsNativeBgBoost
                    ? 'اسمح للتطبيق بالعمل بدون قيود للبطارية (Unrestricted) ومنبّهات الوقت الدقيق حتى لا يوقفه النظام عند الخروج.'
                    : 'التطبيق مستثنى من توفير البطارية ومنبّهاته الدقيقة نشطة.'}
                </p>
              </div>
            </div>

            {needsNativeBgBoost && (
              <button
                type="button"
                onClick={() => void handleEnableBackground()}
                className="btn-glow min-h-[44px] rounded-xl bg-amber-500 px-4 py-2 text-xs font-bold text-slate-950 whitespace-nowrap shrink-0"
              >
                تفعيل العمل في الخلفية
              </button>
            )}
          </div>
        )}
      </section>

      {/* Interval & Dhikr Selection Grid */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        {/* Interval & Time Window */}
        <section className="min-w-0 lg:col-span-6 space-y-5 rounded-3xl border border-blue-300/20 bg-[#140e44]/80 p-5 sm:p-6 shadow-xl">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Clock className="h-5 w-5 text-blue-300 shrink-0" />
              <span>تحديد الفاصل الزمني بين التذكيرات</span>
            </h3>
            <div className="mt-3 grid grid-cols-2 sm:grid-cols-3 gap-2.5">
              {INTERVAL_OPTIONS.map((opt) => (
                <button
                  key={opt.value}
                  type="button"
                  onClick={() => handleSelectInterval(opt.value)}
                  className={`btn-glow min-h-[44px] rounded-xl border px-3 py-2 text-xs font-bold ${
                    reminder.intervalMinutes === opt.value
                      ? 'border-amber-300 bg-gradient-to-l from-violet-600 to-blue-600 text-white'
                      : 'border-white/15 bg-white/5 text-slate-200 hover:bg-white/10'
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                const val = Number(customMinutes);
                if (val >= 1) {
                  handleSelectInterval(val);
                  setCustomMinutes('');
                }
              }}
              className="mt-3 flex gap-2 min-w-0"
            >
              <input
                type="number"
                min={1}
                max={1440}
                value={customMinutes}
                onChange={(e) => setCustomMinutes(e.target.value)}
                placeholder="فاصل مخصص بالدقائق (مثلاً 45)"
                className="min-h-[44px] min-w-0 flex-1 rounded-xl border border-white/15 bg-white/5 px-3 text-sm text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-violet-400"
              />
              <button
                type="submit"
                className="btn-glow min-h-[44px] rounded-xl bg-blue-600 px-4 text-sm font-bold text-white whitespace-nowrap shrink-0"
              >
                حفظ
              </button>
            </form>
          </div>

          {/* Audio & Background KeepAlive Switches */}
          <div className="space-y-3 border-t border-white/10 pt-4">
            <label className="flex items-center justify-between gap-3 rounded-2xl border border-white/10 bg-white/5 p-3.5 cursor-pointer">
              <div className="flex items-center gap-3 min-w-0">
                <Volume2 className="h-5 w-5 text-amber-300 shrink-0" />
                <div className="min-w-0">
                  <p className="text-sm font-bold text-white">
                    تشغيل صوت الذكر تلقائياً
                  </p>
                  <p className="text-xs text-slate-300">
                    يعمل عبر مستوى صوت الإشعارات في الهاتف
                  </p>
                </div>
              </div>
              <input
                type="checkbox"
                checked={reminder.soundEnabled}
                onChange={(e) =>
                  onUpdateReminder({
                    ...reminder,
                    soundEnabled: e.target.checked,
                  })
                }
                className="h-5 w-5 shrink-0 accent-violet-500"
              />
            </label>

            <label className="flex items-center justify-between gap-3 rounded-2xl border border-white/10 bg-white/5 p-3.5 cursor-pointer">
              <div className="flex items-center gap-3 min-w-0">
                <Bell className="h-5 w-5 text-violet-300 shrink-0" />
                <div className="min-w-0">
                  <p className="text-sm font-bold text-white">
                    التشغيل المستمر في الخلفية
                  </p>
                  <p className="text-xs text-slate-300">
                    استمرار التذكير عند قفل الشاشة أو الخروج من التطبيق
                  </p>
                </div>
              </div>
              <input
                type="checkbox"
                checked={reminder.backgroundKeepAlive}
                onChange={(e) => {
                  const active = e.target.checked;
                  if (active && reminder.enabled) {
                    startBackgroundKeepAlive(
                      reminder.customDhikr.trim() || reminder.selectedDhikr
                    );
                  } else {
                    stopBackgroundKeepAlive();
                  }
                  onUpdateReminder({
                    ...reminder,
                    backgroundKeepAlive: active,
                  });
                }}
                className="h-5 w-5 shrink-0 accent-violet-500"
              />
            </label>

            <div className="rounded-2xl border border-white/10 bg-white/5 p-3.5 space-y-3">
              <label className="flex items-center justify-between gap-3 cursor-pointer">
                <div className="flex items-center gap-3 min-w-0">
                  <Moon className="h-5 w-5 text-blue-300 shrink-0" />
                  <div className="min-w-0">
                    <p className="text-sm font-bold text-white">
                      تفعيل ساعات الهدوء (عدم الإزعاج ليلاً)
                    </p>
                    <p className="text-xs text-slate-300">
                      إيقاف الإشعارات بين {reminder.quietStartHour}:00 و{' '}
                      {reminder.quietEndHour}:00
                    </p>
                  </div>
                </div>
                <input
                  type="checkbox"
                  checked={reminder.quietHoursEnabled}
                  onChange={(e) =>
                    onUpdateReminder({
                      ...reminder,
                      quietHoursEnabled: e.target.checked,
                    })
                  }
                  className="h-5 w-5 shrink-0 accent-violet-500"
                />
              </label>

              {reminder.quietHoursEnabled && (
                <div className="grid grid-cols-2 gap-2.5 border-t border-white/10 pt-3">
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                      من الساعة
                    </label>
                    <select
                      value={reminder.quietStartHour}
                      onChange={(e) =>
                        onUpdateReminder({
                          ...reminder,
                          quietStartHour: Number(e.target.value),
                        })
                      }
                      className="min-h-[40px] w-full rounded-xl border border-white/15 bg-[#1b1255] px-2.5 text-xs font-semibold text-white focus:outline-none focus:ring-2 focus:ring-violet-400"
                    >
                      {HOURS_LIST.map((h) => (
                        <option key={h.value} value={h.value}>
                          {h.label}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                      إلى الساعة
                    </label>
                    <select
                      value={reminder.quietEndHour}
                      onChange={(e) =>
                        onUpdateReminder({
                          ...reminder,
                          quietEndHour: Number(e.target.value),
                        })
                      }
                      className="min-h-[40px] w-full rounded-xl border border-white/15 bg-[#1b1255] px-2.5 text-xs font-semibold text-white focus:outline-none focus:ring-2 focus:ring-violet-400"
                    >
                      {HOURS_LIST.map((h) => (
                        <option key={h.value} value={h.value}>
                          {h.label}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
              )}
            </div>
          </div>
        </section>

        {/* Choose Dhikr for Reminder */}
        <section className="min-w-0 lg:col-span-6 rounded-3xl border border-violet-300/20 bg-[#150f44]/80 p-5 sm:p-6 shadow-xl">
          <h3 className="text-base font-bold text-white">
            اختر نص الذكر في الإشعار
          </h3>
          <div className="mt-3 space-y-2.5">
            {DHIKR_PRESETS.map((item) => {
              const selected =
                !reminder.customDhikr.trim() &&
                reminder.selectedDhikr === item.text;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() =>
                    onUpdateReminder({
                      ...reminder,
                      selectedDhikr: item.text,
                      customDhikr: '',
                    })
                  }
                  className={`btn-glow w-full rounded-2xl border p-3.5 text-right ${
                    selected
                      ? 'border-amber-300/60 bg-gradient-to-l from-violet-600/45 to-blue-700/45 text-white'
                      : 'border-white/10 bg-white/5 text-slate-200 hover:bg-white/10'
                  }`}
                >
                  <p className="text-sm font-bold">{item.text}</p>
                </button>
              );
            })}
          </div>

          <div className="mt-4">
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              أو اكتب ذكراً مخصصاً للتذكير به:
            </label>
            <input
              type="text"
              value={reminder.customDhikr}
              onChange={(e) =>
                onUpdateReminder({ ...reminder, customDhikr: e.target.value })
              }
              placeholder="مثال: اللهم صلّ وسلم على نبينا محمد ﷺ"
              className="min-h-[44px] w-full min-w-0 rounded-xl border border-white/15 bg-white/5 px-3.5 text-sm text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-violet-400"
            />
          </div>
        </section>
      </div>
    </div>
  );
};
