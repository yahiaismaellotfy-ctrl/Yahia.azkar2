import React, { useState } from 'react';
import { Download, Smartphone, X } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface PWAInstallButtonProps {
  compact?: boolean;
}

export const PWAInstallButton: React.FC<PWAInstallButtonProps> = ({ compact = false }) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showIOSGuide, setShowIOSGuide] = useState(false);

  if (isInstalled) {
    return null;
  }

  if (isInstallable) {
    return (
      <button
        type="button"
        onClick={() => void install()}
        className={`btn-glow flex items-center justify-center gap-2 rounded-xl bg-gradient-to-l from-violet-600 to-blue-600 font-semibold text-white shadow-lg shadow-violet-900/40 whitespace-nowrap shrink-0 ${
          compact ? 'min-h-[44px] px-3 py-2 text-xs' : 'min-h-[48px] px-5 py-3 text-sm w-full'
        }`}
      >
        <Download className="h-4 w-4 shrink-0" />
        <span>تثبيت التطبيق</span>
      </button>
    );
  }

  if (isIOS) {
    return (
      <>
        <button
          type="button"
          onClick={() => setShowIOSGuide(true)}
          className={`btn-glow flex items-center justify-center gap-2 rounded-xl border border-violet-400/35 bg-violet-950/60 font-semibold text-violet-100 whitespace-nowrap shrink-0 ${
            compact ? 'min-h-[44px] px-3 py-2 text-xs' : 'min-h-[48px] px-5 py-3 text-sm w-full'
          }`}
        >
          <Smartphone className="h-4 w-4 shrink-0" />
          <span>تثبيت على آيفون</span>
        </button>

        {showIOSGuide && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
            <div className="w-full max-w-sm rounded-3xl border border-violet-400/25 bg-[#190e42] p-6 text-right shadow-2xl">
              <div className="flex items-center justify-between gap-3">
                <h3 className="text-lg font-bold text-white">تثبيت التطبيق على iPhone / iPad</h3>
                <button
                  type="button"
                  onClick={() => setShowIOSGuide(false)}
                  className="flex h-10 w-10 items-center justify-center rounded-xl bg-white/10 text-slate-200 hover:bg-white/20"
                  aria-label="إغلاق"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>
              <ol className="mt-4 space-y-2.5 text-sm leading-relaxed text-slate-200">
                <li>1. اضغط على زر <strong>المشاركة (Share)</strong> في شريط متصفح Safari بالأسفل.</li>
                <li>2. مرر للأسفل واختر <strong>إضافة إلى الشاشة الرئيسية (Add to Home Screen)</strong>.</li>
                <li>3. اضغط <strong>إضافة</strong> ليظهر التطبيق باسمه وصورته على شاشة الهاتف.</li>
              </ol>
              <button
                type="button"
                onClick={() => setShowIOSGuide(false)}
                className="btn-glow mt-5 min-h-[44px] w-full rounded-xl bg-gradient-to-l from-violet-600 to-blue-600 py-2.5 text-sm font-bold text-white"
              >
                فهمت
              </button>
            </div>
          </div>
        )}
      </>
    );
  }

  return null;
};
