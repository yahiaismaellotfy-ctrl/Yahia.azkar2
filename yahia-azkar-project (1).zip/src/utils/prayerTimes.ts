import { CalculationMethod, Coordinates, PrayerTimes } from 'adhan';

export interface CityPreset {
  id: string;
  nameAr: string;
  countryAr: string;
  lat: number;
  lng: number;
  method: 'egyptian' | 'ummAlQura' | 'muslimWorldLeague' | 'dubai';
}

export const CITIES: CityPreset[] = [
  { id: 'cairo', nameAr: 'القاهرة', countryAr: 'مصر', lat: 30.0444, lng: 31.2357, method: 'egyptian' },
  { id: 'alexandria', nameAr: 'الإسكندرية', countryAr: 'مصر', lat: 31.2001, lng: 29.9187, method: 'egyptian' },
  { id: 'giza', nameAr: 'الجيزة', countryAr: 'مصر', lat: 30.0131, lng: 31.2089, method: 'egyptian' },
  { id: 'mansoura', nameAr: 'المنصورة', countryAr: 'مصر', lat: 31.0409, lng: 31.3785, method: 'egyptian' },
  { id: 'aswan', nameAr: 'أسوان', countryAr: 'مصر', lat: 24.0889, lng: 32.8998, method: 'egyptian' },
  { id: 'mecca', nameAr: 'مكة المكرمة', countryAr: 'السعودية', lat: 21.3891, lng: 39.8579, method: 'ummAlQura' },
  { id: 'medina', nameAr: 'المدينة المنورة', countryAr: 'السعودية', lat: 24.5247, lng: 39.5692, method: 'ummAlQura' },
  { id: 'riyadh', nameAr: 'الرياض', countryAr: 'السعودية', lat: 24.7136, lng: 46.6753, method: 'ummAlQura' },
  { id: 'dubai', nameAr: 'دبي', countryAr: 'الإمارات', lat: 25.2048, lng: 55.2708, method: 'dubai' },
  { id: 'doha', nameAr: 'الدوحة', countryAr: 'قطر', lat: 25.2854, lng: 51.531, method: 'ummAlQura' },
  { id: 'amman', nameAr: 'عمّان', countryAr: 'الأردن', lat: 31.9454, lng: 35.9284, method: 'muslimWorldLeague' },
  { id: 'baghdad', nameAr: 'بغداد', countryAr: 'العراق', lat: 33.3152, lng: 44.3661, method: 'muslimWorldLeague' },
  { id: 'casablanca', nameAr: 'الدار البيضاء', countryAr: 'المغرب', lat: 33.5731, lng: -7.5898, method: 'muslimWorldLeague' },
  { id: 'tunis', nameAr: 'تونس', countryAr: 'تونس', lat: 36.8065, lng: 10.1815, method: 'muslimWorldLeague' },
];

export interface PrayerEntry {
  key: 'fajr' | 'sunrise' | 'dhuhr' | 'asr' | 'maghrib' | 'isha';
  nameAr: string;
  time: Date;
  formattedTime: string;
  isNext: boolean;
}

export interface PrayerScheduleResult {
  prayers: PrayerEntry[];
  nextPrayer: PrayerEntry;
  remainingText: string;
  cityLabel: string;
}

function getCalculationParams(method: CityPreset['method']) {
  switch (method) {
    case 'ummAlQura':
      return CalculationMethod.UmmAlQura();
    case 'dubai':
      return CalculationMethod.Dubai();
    case 'muslimWorldLeague':
      return CalculationMethod.MuslimWorldLeague();
    case 'egyptian':
    default:
      return CalculationMethod.Egyptian();
  }
}

export function formatTimeAr(date: Date): string {
  return date.toLocaleTimeString('ar-EG', {
    hour: '2-digit',
    minute: '2-digit',
    hour12: true,
  });
}

export function computePrayerSchedule(
  cityId: string,
  customCoords: { lat: number; lng: number; label: string } | null,
  now: Date = new Date()
): PrayerScheduleResult {
  const preset = CITIES.find((c) => c.id === cityId) || CITIES[0];
  const lat = customCoords ? customCoords.lat : preset.lat;
  const lng = customCoords ? customCoords.lng : preset.lng;
  const cityLabel = customCoords ? customCoords.label : `${preset.nameAr}، ${preset.countryAr}`;

  const coordinates = new Coordinates(lat, lng);
  const params = getCalculationParams(preset.method);
  const todayTimes = new PrayerTimes(coordinates, now, params);

  const rawEntries: Array<{ key: PrayerEntry['key']; nameAr: string; time: Date }> = [
    { key: 'fajr', nameAr: 'الفجر', time: todayTimes.fajr },
    { key: 'sunrise', nameAr: 'الشروق', time: todayTimes.sunrise },
    { key: 'dhuhr', nameAr: 'الظهر', time: todayTimes.dhuhr },
    { key: 'asr', nameAr: 'العصر', time: todayTimes.asr },
    { key: 'maghrib', nameAr: 'المغرب', time: todayTimes.maghrib },
    { key: 'isha', nameAr: 'العشاء', time: todayTimes.isha },
  ];

  // Determine next upcoming prayer (check today, else tomorrow Fajr)
  let nextKey: PrayerEntry['key'] | null = null;
  let nextTime: Date | null = null;

  for (const item of rawEntries) {
    if (item.key === 'sunrise') continue;
    if (item.time.getTime() > now.getTime()) {
      nextKey = item.key;
      nextTime = item.time;
      break;
    }
  }

  if (!nextKey || !nextTime) {
    const tomorrow = new Date(now);
    tomorrow.setDate(tomorrow.getDate() + 1);
    const tomorrowTimes = new PrayerTimes(coordinates, tomorrow, params);
    nextKey = 'fajr';
    nextTime = tomorrowTimes.fajr;
  }

  const prayers: PrayerEntry[] = rawEntries.map((item) => ({
    key: item.key,
    nameAr: item.nameAr,
    time: item.time,
    formattedTime: formatTimeAr(item.time),
    isNext: item.key === nextKey,
  }));

  const nextPrayer = prayers.find((p) => p.key === nextKey) || prayers[0];
  const diffMs = Math.max(0, nextTime.getTime() - now.getTime());
  const totalSec = Math.floor(diffMs / 1000);
  const hours = Math.floor(totalSec / 3600);
  const minutes = Math.floor((totalSec % 3600) / 60);
  const seconds = totalSec % 60;

  const pad = (n: number) => String(n).padStart(2, '0');
  const remainingText = `${pad(hours)}:${pad(minutes)}:${pad(seconds)}`;

  return {
    prayers,
    nextPrayer,
    remainingText,
    cityLabel,
  };
}
