import { Capacitor, registerPlugin } from '@capacitor/core';
import { Haptics, ImpactStyle } from '@capacitor/haptics';
import { LocalNotifications } from '@capacitor/local-notifications';
import type { ReminderConfig } from './storage';

export const REMINDER_AUDIO_URL = '/assets/aistudio/______________f40c9c68.mp3';

export interface NativeBackgroundStatus {
  notificationsEnabled: boolean;
  canExactAlarms: boolean;
  ignoringBattery: boolean;
}

interface AzkarReminderNativePlugin {
  scheduleReminder(options: {
    enabled: boolean;
    intervalMinutes: number;
    phrase: string;
    soundEnabled: boolean;
    vibrateEnabled: boolean;
    quietHoursEnabled: boolean;
    quietStartHour: number;
    quietEndHour: number;
    nextTriggerAt: number;
  }): Promise<{ scheduled: boolean; nextTriggerAt: number }>;
  testNotificationNow(options: {
    phrase: string;
    soundEnabled: boolean;
    vibrateEnabled: boolean;
  }): Promise<void>;
  playNotificationSound(options: {
    volume: number;
  }): Promise<{ playing: boolean; durationMs: number }>;
  stopNotificationSound(): Promise<void>;
  getBackgroundStatus(): Promise<NativeBackgroundStatus>;
  requestBackgroundPermissions(): Promise<void>;
}

const AzkarReminder = registerPlugin<AzkarReminderNativePlugin>('AzkarReminder');

let activeAudioEl: HTMLAudioElement | null = null;
let nativePlaybackTimer: ReturnType<typeof setTimeout> | null = null;
let keepAliveAudioCtx: AudioContext | null = null;
let keepAliveOscillator: OscillatorNode | null = null;
let keepAliveGain: GainNode | null = null;

export async function playReminderAudio(
  volume = 0.9,
  onEnded?: () => void
): Promise<boolean> {
  if (nativePlaybackTimer) {
    clearTimeout(nativePlaybackTimer);
    nativePlaybackTimer = null;
  }

  if (Capacitor.isNativePlatform()) {
    try {
      const clampedVol = Math.max(0.05, Math.min(1, volume));
      const res = await AzkarReminder.playNotificationSound({ volume: clampedVol });
      if (res.playing) {
        const waitMs = Math.max(1500, res.durationMs || 8000);
        nativePlaybackTimer = setTimeout(() => {
          nativePlaybackTimer = null;
          onEnded?.();
        }, waitMs);
      } else {
        onEnded?.();
      }
      return res.playing;
    } catch {
      onEnded?.();
      return false;
    }
  }

  try {
    if (!activeAudioEl) {
      activeAudioEl = new Audio(REMINDER_AUDIO_URL);
    }
    activeAudioEl.onended = () => {
      onEnded?.();
    };
    activeAudioEl.pause();
    activeAudioEl.currentTime = 0;
    activeAudioEl.volume = Math.max(0, Math.min(1, volume));
    await activeAudioEl.play();
    return true;
  } catch {
    onEnded?.();
    return false;
  }
}

export function stopReminderAudio(): void {
  if (nativePlaybackTimer) {
    clearTimeout(nativePlaybackTimer);
    nativePlaybackTimer = null;
  }

  if (Capacitor.isNativePlatform()) {
    void AzkarReminder.stopNotificationSound().catch(() => {});
  }

  if (activeAudioEl) {
    activeAudioEl.onended = null;
    activeAudioEl.pause();
    activeAudioEl.currentTime = 0;
  }
}

export function playGoalChime(): void {
  try {
    const AudioCtx =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext: typeof AudioContext })
        .webkitAudioContext;
    if (!AudioCtx) return;
    const ctx = new AudioCtx();
    const notes = [523.25, 659.25, 783.99, 1046.5];
    notes.forEach((freq, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.value = freq;
      const start = ctx.currentTime + i * 0.11;
      gain.gain.setValueAtTime(0.001, start);
      gain.gain.exponentialRampToValueAtTime(0.14, start + 0.03);
      gain.gain.exponentialRampToValueAtTime(0.001, start + 0.45);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(start);
      osc.stop(start + 0.46);
    });
  } catch {
    // Ignore audio context restriction errors
  }
}

/**
 * Enables a near-silent background audio session + MediaSession metadata
 * on mobile web browsers so they do not suspend scheduled audio reminders while locked.
 */
export function startBackgroundKeepAlive(dhikrTitle: string): void {
  if (Capacitor.isNativePlatform()) return;
  try {
    if ('mediaSession' in navigator) {
      navigator.mediaSession.metadata = new MediaMetadata({
        title: dhikrTitle || 'صلّ على الحبيب محمد ﷺ',
        artist: '𝐘𝐀𝐇𝐈𝐀 𝐃𝐈𝐒𝐓𝐑𝐎𝐕𝐀',
        album: '{𝐘𝐀𝐇𝐈𝐀}صلـى عـلى الـحـبيـب♥✨',
        artwork: [
          { src: '/pwa-192x192.png', sizes: '192x192', type: 'image/png' },
          { src: '/pwa-512x512.png', sizes: '512x512', type: 'image/png' },
        ],
      });
    }

    const AudioCtx =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext: typeof AudioContext })
        .webkitAudioContext;
    if (!AudioCtx || keepAliveAudioCtx) return;

    keepAliveAudioCtx = new AudioCtx();
    keepAliveOscillator = keepAliveAudioCtx.createOscillator();
    keepAliveGain = keepAliveAudioCtx.createGain();
    keepAliveOscillator.frequency.value = 20;
    keepAliveGain.gain.value = 0.0001;
    keepAliveOscillator.connect(keepAliveGain);
    keepAliveGain.connect(keepAliveAudioCtx.destination);
    keepAliveOscillator.start();
  } catch {
    // Browser may require user gesture first
  }
}

export function stopBackgroundKeepAlive(): void {
  try {
    if (keepAliveOscillator) {
      keepAliveOscillator.stop();
      keepAliveOscillator.disconnect();
      keepAliveOscillator = null;
    }
    if (keepAliveGain) {
      keepAliveGain.disconnect();
      keepAliveGain = null;
    }
    if (keepAliveAudioCtx) {
      void keepAliveAudioCtx.close();
      keepAliveAudioCtx = null;
    }
  } catch {
    // Ignore cleanup errors
  }
}

export function triggerHaptic(pattern: number | number[] = 25): void {
  if (Capacitor.isNativePlatform()) {
    void Haptics.impact({ style: ImpactStyle.Light }).catch(() => {});
    return;
  }
  if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
    try {
      navigator.vibrate(pattern);
    } catch {
      // Ignore vibrate restrictions
    }
  }
}

export async function checkNotificationPermission(): Promise<NotificationPermission> {
  if (Capacitor.isNativePlatform()) {
    try {
      const [perm, status] = await Promise.all([
        LocalNotifications.checkPermissions(),
        AzkarReminder.getBackgroundStatus().catch(() => null),
      ]);
      if (perm.display === 'granted' && (status === null || status.notificationsEnabled)) {
        return 'granted';
      }
      if (perm.display === 'denied') return 'denied';
      return 'default';
    } catch {
      return 'default';
    }
  }

  if (typeof Notification === 'undefined') return 'denied';
  return Notification.permission;
}

export async function requestNotificationPermission(): Promise<NotificationPermission> {
  if (Capacitor.isNativePlatform()) {
    try {
      const res = await LocalNotifications.requestPermissions();
      if (res.display === 'granted') return 'granted';
      const status = await AzkarReminder.getBackgroundStatus().catch(() => null);
      if (status?.notificationsEnabled) return 'granted';
      return res.display === 'denied' ? 'denied' : 'default';
    } catch {
      return 'denied';
    }
  }

  if (typeof Notification === 'undefined') return 'denied';
  if (Notification.permission === 'granted') return 'granted';
  try {
    return await Notification.requestPermission();
  } catch {
    return 'denied';
  }
}

export async function getNativeBackgroundStatus(): Promise<NativeBackgroundStatus | null> {
  if (!Capacitor.isNativePlatform()) return null;
  try {
    return await AzkarReminder.getBackgroundStatus();
  } catch {
    return null;
  }
}

export async function requestNativeBackgroundPermissions(): Promise<void> {
  if (!Capacitor.isNativePlatform()) return;
  try {
    await AzkarReminder.requestBackgroundPermissions();
  } catch {
    // Ignore settings intent errors
  }
}

export async function syncReminderWithServiceWorker(
  config: ReminderConfig
): Promise<void> {
  // Native Android: persist in SharedPreferences + AlarmManager exact alarm + BootReceiver
  if (Capacitor.isNativePlatform()) {
    try {
      const phrase =
        config.customDhikr.trim() ||
        config.selectedDhikr ||
        'اللهم صلّ وسلم وبارك على نبينا محمد ﷺ';
      const intervalMs = Math.max(1, config.intervalMinutes) * 60 * 1000;
      const nextTriggerAt =
        config.nextTriggerAt && config.nextTriggerAt > Date.now()
          ? config.nextTriggerAt
          : Date.now() + intervalMs;

      await AzkarReminder.scheduleReminder({
        enabled: config.enabled,
        intervalMinutes: Math.max(1, config.intervalMinutes),
        phrase,
        soundEnabled: config.soundEnabled,
        vibrateEnabled: config.vibrateEnabled,
        quietHoursEnabled: config.quietHoursEnabled,
        quietStartHour: config.quietStartHour,
        quietEndHour: config.quietEndHour,
        nextTriggerAt,
      });
    } catch {
      // Native scheduling error ignored
    }
    return;
  }

  // Web / PWA Service Worker scheduling
  if (!('serviceWorker' in navigator)) return;
  try {
    const registration = await navigator.serviceWorker.ready;
    const sw = registration.active || navigator.serviceWorker.controller;
    if (sw) {
      sw.postMessage({
        type: config.enabled ? 'SCHEDULE_REMINDER' : 'CANCEL_REMINDER',
        config,
      });
    }

    const periodicReg = registration as ServiceWorkerRegistration & {
      periodicSync?: {
        register: (
          tag: string,
          options?: { minInterval: number }
        ) => Promise<void>;
        unregister: (tag: string) => Promise<void>;
      };
    };

    if (periodicReg.periodicSync) {
      if (config.enabled) {
        await periodicReg.periodicSync.register('azkar-reminder-sync', {
          minInterval: Math.max(15, config.intervalMinutes) * 60 * 1000,
        });
      } else {
        await periodicReg.periodicSync.unregister('azkar-reminder-sync');
      }
    }
  } catch {
    // Periodic sync permission may not be granted until PWA installed
  }
}

export async function sendTestReminderToSW(
  phrase = 'سبحان الله والحمد لله والله أكبر — اللهم صلّ وسلم على نبينا محمد ﷺ',
  soundEnabled = true,
  vibrateEnabled = true
): Promise<void> {
  if (Capacitor.isNativePlatform()) {
    try {
      await AzkarReminder.testNotificationNow({
        phrase,
        soundEnabled,
        vibrateEnabled,
      });
    } catch {
      // Ignore native test error
    }
    return;
  }

  if (!('serviceWorker' in navigator)) return;
  try {
    const registration = await navigator.serviceWorker.ready;
    const sw = registration.active || navigator.serviceWorker.controller;
    sw?.postMessage({ type: 'TEST_REMINDER' });
  } catch {
    // Fallback handled in UI
  }
}
