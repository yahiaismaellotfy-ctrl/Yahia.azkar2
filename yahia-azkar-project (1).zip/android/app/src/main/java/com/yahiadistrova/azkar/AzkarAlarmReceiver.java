package com.yahiadistrova.azkar;

import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.AudioAttributes;
import android.net.Uri;
import android.os.Build;
import android.os.PowerManager;

import androidx.core.app.NotificationCompat;

import java.util.Calendar;

public class AzkarAlarmReceiver extends BroadcastReceiver {
    public static final String PREFS_NAME = "azkar_reminder_prefs";
    public static final String CHANNEL_ID = "azkar_notif_channel_v2";
    public static final int ALARM_REQUEST_CODE = 7701;
    public static final int NOTIF_ID = 7702;

    @Override
    public void onReceive(Context context, Intent intent) {
        PowerManager pm = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
        PowerManager.WakeLock wakeLock = null;
        if (pm != null) {
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "yahia:AzkarAlarmWakeLock");
            wakeLock.acquire(5000L);
        }

        try {
            SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
            boolean enabled = prefs.getBoolean("enabled", false);
            if (!enabled) {
                return;
            }

            int intervalMinutes = Math.max(1, prefs.getInt("intervalMinutes", 15));
            String phrase = prefs.getString("phrase", "اللهم صلّ وسلم وبارك على نبينا محمد ﷺ");
            boolean soundEnabled = prefs.getBoolean("soundEnabled", true);
            boolean vibrateEnabled = prefs.getBoolean("vibrateEnabled", true);
            boolean quietHoursEnabled = prefs.getBoolean("quietHoursEnabled", false);
            int quietStartHour = prefs.getInt("quietStartHour", 23);
            int quietEndHour = prefs.getInt("quietEndHour", 5);

            if (!isWithinQuietHours(quietHoursEnabled, quietStartHour, quietEndHour)) {
                showReminderNotification(context, phrase, soundEnabled, vibrateEnabled);
            }

            // Schedule next repeating exact alarm so it runs continuously forever
            long nextTriggerAt = System.currentTimeMillis() + (intervalMinutes * 60_000L);
            prefs.edit().putLong("nextTriggerAt", nextTriggerAt).apply();
            scheduleNextAlarm(context, nextTriggerAt);
        } finally {
            if (wakeLock != null && wakeLock.isHeld()) {
                try {
                    wakeLock.release();
                } catch (Exception ignored) {
                }
            }
        }
    }

    private static boolean isWithinQuietHours(boolean enabled, int startHour, int endHour) {
        if (!enabled) return false;
        int hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        if (startHour <= endHour) {
            return hour >= startHour && hour < endHour;
        }
        return hour >= startHour || hour < endHour;
    }

    public static void ensureNotificationChannel(Context context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return;

        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;

        NotificationChannel existing = nm.getNotificationChannel(CHANNEL_ID);
        if (existing != null) return;

        NotificationChannel channel = new NotificationChannel(
            CHANNEL_ID,
            "تذكير الأذكار بالصوت",
            NotificationManager.IMPORTANCE_HIGH
        );
        channel.setDescription("تنبيهات الأذكار الدورية بصوت الإشعارات");
        channel.enableVibration(true);
        channel.setVibrationPattern(new long[]{0, 220, 120, 220});
        channel.setLockscreenVisibility(NotificationCompat.VISIBILITY_PUBLIC);

        Uri soundUri = Uri.parse("android.resource://" + context.getPackageName() + "/" + R.raw.azkar_reminder);
        AudioAttributes attrs = new AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_NOTIFICATION)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build();
        channel.setSound(soundUri, attrs);

        nm.createNotificationChannel(channel);
    }

    public static void showReminderNotification(Context context, String phrase, boolean soundEnabled, boolean vibrateEnabled) {
        ensureNotificationChannel(context);
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;

        Intent launchIntent = new Intent(context, MainActivity.class);
        launchIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        int piFlags = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ? PendingIntent.FLAG_IMMUTABLE : 0);
        PendingIntent contentIntent = PendingIntent.getActivity(context, 0, launchIntent, piFlags);

        Uri soundUri = Uri.parse("android.resource://" + context.getPackageName() + "/" + R.raw.azkar_reminder);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_azkar)
            .setColor(0xFF7C3AED)
            .setContentTitle("✨ {𝐘𝐀𝐇𝐈𝐀} صلّى على الحبيب ♥")
            .setContentText(phrase)
            .setStyle(new NotificationCompat.BigTextStyle().bigText(phrase + "\nسبحان الله والحمد لله والله أكبر"))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setAutoCancel(true)
            .setContentIntent(contentIntent);

        if (soundEnabled) {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
                builder.setSound(soundUri, android.media.AudioManager.STREAM_NOTIFICATION);
            }
        } else {
            builder.setSilent(true);
        }

        if (vibrateEnabled) {
            builder.setVibrate(new long[]{0, 220, 120, 220});
        }

        nm.notify(NOTIF_ID, builder.build());
    }

    public static void scheduleNextAlarm(Context context, long triggerAtMillis) {
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;

        Intent intent = new Intent(context, AzkarAlarmReceiver.class);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ? PendingIntent.FLAG_IMMUTABLE : 0);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(context, ALARM_REQUEST_CODE, intent, flags);

        am.cancel(pendingIntent);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (am.canScheduleExactAlarms()) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pendingIntent);
            } else {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pendingIntent);
            }
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pendingIntent);
        } else {
            am.setExact(AlarmManager.RTC_WAKEUP, triggerAtMillis, pendingIntent);
        }
    }

    public static void cancelAlarm(Context context) {
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;

        Intent intent = new Intent(context, AzkarAlarmReceiver.class);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ? PendingIntent.FLAG_IMMUTABLE : 0);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(context, ALARM_REQUEST_CODE, intent, flags);
        am.cancel(pendingIntent);
    }
}
