package com.yahiadistrova.azkar;

import android.os.Bundle;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(AzkarReminderPlugin.class);
        super.onCreate(savedInstanceState);
        AzkarAlarmReceiver.ensureNotificationChannel(this);
    }
}
