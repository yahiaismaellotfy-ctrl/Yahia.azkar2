package com.yahiadistrova.azkar;

import android.app.AlarmManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.PowerManager;
import android.provider.Settings;

import androidx.core.app.NotificationManagerCompat;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

@CapacitorPlugin(name = "AzkarReminder")
public class AzkarReminderPlugin extends Plugin {
    private static MediaPlayer activePlayer = null;

    @PluginMethod
    public void scheduleReminder(PluginCall call) {
        Context context = getContext();
        boolean enabled = Boolean.TRUE.equals(call.getBoolean("enabled", false));
        int intervalMinutes = Math.max(1, call.getInt("intervalMinutes", 15));
        String phrase = call.getString("phrase", "اللهم صلّ وسلم وبارك على نبينا محمد ﷺ");
        boolean soundEnabled = Boolean.TRUE.equals(call.getBoolean("soundEnabled", true));
        boolean vibrateEnabled = Boolean.TRUE.equals(call.getBoolean("vibrateEnabled", true));
        boolean quietHoursEnabled = Boolean.TRUE.equals(call.getBoolean("quietHoursEnabled", false));
        int quietStartHour = call.getInt("quietStartHour", 23);
        int quietEndHour = call.getInt("quietEndHour", 5);
        long nextTriggerAt = call.getDouble("nextTriggerAt") != null
            ? call.getDouble("nextTriggerAt").longValue()
            : System.currentTimeMillis() + (intervalMinutes * 60_000L);

        if (nextTriggerAt <= System.currentTimeMillis()) {
            nextTriggerAt = System.currentTimeMillis() + (intervalMinutes * 60_000L);
        }

        SharedPreferences prefs = context.getSharedPreferences(AzkarAlarmReceiver.PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit()
            .putBoolean("enabled", enabled)
            .putInt("intervalMinutes", intervalMinutes)
            .putString("phrase", phrase)
            .putBoolean("soundEnabled", soundEnabled)
            .putBoolean("vibrateEnabled", vibrateEnabled)
            .putBoolean("quietHoursEnabled", quietHoursEnabled)
            .putInt("quietStartHour", quietStartHour)
            .putInt("quietEndHour", quietEndHour)
            .putLong("nextTriggerAt", nextTriggerAt)
            .apply();

        AzkarAlarmReceiver.ensureNotificationChannel(context);

        if (enabled) {
            AzkarAlarmReceiver.scheduleNextAlarm(context, nextTriggerAt);
        } else {
            AzkarAlarmReceiver.cancelAlarm(context);
        }

        JSObject ret = new JSObject();
        ret.put("scheduled", enabled);
        ret.put("nextTriggerAt", nextTriggerAt);
        call.resolve(ret);
    }

    @PluginMethod
    public void testNotificationNow(PluginCall call) {
        Context context = getContext();
        String phrase = call.getString("phrase", "سبحان الله والحمد لله والله أكبر — اللهم صلّ وسلم على نبينا محمد ﷺ");
        boolean soundEnabled = Boolean.TRUE.equals(call.getBoolean("soundEnabled", true));
        boolean vibrateEnabled = Boolean.TRUE.equals(call.getBoolean("vibrateEnabled", true));

        AzkarAlarmReceiver.showReminderNotification(context, phrase, soundEnabled, vibrateEnabled);
        call.resolve();
    }

    @PluginMethod
    public void playNotificationSound(PluginCall call) {
        Context context = getContext();
        float volume = call.getFloat("volume", 1.0f);
        try {
            stopActivePlayer();
            Uri soundUri = Uri.parse("android.resource://" + context.getPackageName() + "/" + R.raw.azkar_reminder);
            MediaPlayer mp = new MediaPlayer();
            AudioAttributes attrs = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build();
            mp.setAudioAttributes(attrs);
            mp.setDataSource(context, soundUri);
            mp.setVolume(volume, volume);
            mp.setOnCompletionListener(player -> {
                player.release();
                if (activePlayer == player) {
                    activePlayer = null;
                }
            });
            mp.prepare();
            int durationMs = Math.max(1000, mp.getDuration());
            mp.start();
            activePlayer = mp;

            JSObject ret = new JSObject();
            ret.put("playing", true);
            ret.put("durationMs", durationMs);
            call.resolve(ret);
        } catch (Exception e) {
            JSObject ret = new JSObject();
            ret.put("playing", false);
            ret.put("durationMs", 0);
            call.resolve(ret);
        }
    }

    @PluginMethod
    public void stopNotificationSound(PluginCall call) {
        stopActivePlayer();
        call.resolve();
    }

    @PluginMethod
    public void getBackgroundStatus(PluginCall call) {
        Context context = getContext();
        boolean notificationsEnabled = NotificationManagerCompat.from(context).areNotificationsEnabled();

        boolean canExactAlarms = true;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            canExactAlarms = am != null && am.canScheduleExactAlarms();
        }

        boolean ignoringBattery = true;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            PowerManager pm = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
            ignoringBattery = pm != null && pm.isIgnoringBatteryOptimizations(context.getPackageName());
        }

        JSObject ret = new JSObject();
        ret.put("notificationsEnabled", notificationsEnabled);
        ret.put("canExactAlarms", canExactAlarms);
        ret.put("ignoringBattery", ignoringBattery);
        call.resolve(ret);
    }

    @PluginMethod
    public void requestBackgroundPermissions(PluginCall call) {
        Context context = getContext();
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
                if (am != null && !am.canScheduleExactAlarms()) {
                    Intent exactIntent = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM);
                    exactIntent.setData(Uri.parse("package:" + context.getPackageName()));
                    exactIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(exactIntent);
                    call.resolve();
                    return;
                }
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                PowerManager pm = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
                if (pm != null && !pm.isIgnoringBatteryOptimizations(context.getPackageName())) {
                    Intent batteryIntent = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
                    batteryIntent.setData(Uri.parse("package:" + context.getPackageName()));
                    batteryIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(batteryIntent);
                    call.resolve();
                    return;
                }
            }

            Intent appSettings = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            appSettings.setData(Uri.parse("package:" + context.getPackageName()));
            appSettings.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(appSettings);
        } catch (Exception ignored) {
            // Ignore settings activity failures
        }
        call.resolve();
    }

    private static void stopActivePlayer() {
        if (activePlayer != null) {
            try {
                if (activePlayer.isPlaying()) {
                    activePlayer.stop();
                }
                activePlayer.release();
            } catch (Exception ignored) {
            }
            activePlayer = null;
        }
    }
}
