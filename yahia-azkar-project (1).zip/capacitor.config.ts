import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.yahiadistrova.azkar',
  appName: '{𝐘𝐀𝐇𝐈𝐀}صلـى عـلى الـحـبيـب♥✨',
  webDir: 'dist',
  android: {
    allowMixedContent: false,
    backgroundColor: '#120931',
  },
  plugins: {
    LocalNotifications: {
      smallIcon: 'ic_stat_azkar',
      iconColor: '#A855F7',
      sound: 'azkar_reminder.mp3',
    },
  },
};

export default config;
